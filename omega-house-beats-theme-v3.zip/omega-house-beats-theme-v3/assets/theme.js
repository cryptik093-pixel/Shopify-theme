document.documentElement.classList.remove('no-js');

document.addEventListener('play', function (event) {
  if (event.target.tagName !== 'AUDIO') return;
  document.querySelectorAll('audio').forEach(function (audio) {
    if (audio !== event.target) audio.pause();
  });
}, true);

(function () {
  var sticky = document.querySelector('[data-sticky-mobile-cta]');
  if (!sticky) return;
  function toggleSticky() {
    if (window.innerWidth > 989) {
      sticky.classList.remove('is-visible');
      return;
    }
    var heroButton = document.querySelector('.hero .button');
    if (!heroButton) {
      sticky.classList.add('is-visible');
      return;
    }
    var rect = heroButton.getBoundingClientRect();
    sticky.classList.toggle('is-visible', rect.bottom < 0);
  }
  window.addEventListener('scroll', toggleSticky, { passive: true });
  window.addEventListener('resize', toggleSticky);
  toggleSticky();
})();
