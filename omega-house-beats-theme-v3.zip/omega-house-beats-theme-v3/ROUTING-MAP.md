# Omega House Beats Theme V3 — Revenue Routing Map

Set these once in Theme Settings -> Revenue routing:

- Funnel landing page URL
- Beta offer URL
- Core offer URL
- Signature offer URL
- Premier Collection I URL
- Premier Collection II URL
- Premier Collection III URL
- Premier Bundle URL
- Mix & Master URL
- Custom Beat Request URL

After those are set, the following surfaces resolve automatically when their local section links are blank:

- announcement CTA
- hero primary CTA
- audio proof CTA
- beta section CTA
- core comparison buttons
- Premier pack buttons and bundle button
- services buttons
- final CTA bar
- sticky mobile CTA
- product-page secondary CTA
- cart upsells
- header CTA
- footer CTA

This makes iteration faster because you can change the entire store routing stack from one place.
